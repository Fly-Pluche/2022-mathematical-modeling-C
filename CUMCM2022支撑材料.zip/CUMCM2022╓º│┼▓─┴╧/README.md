
## 随机森林数据填补：
rfimput_1.ipynb
rfimput_2.ipynb：数据填补，百分比数据统计，直方图
rfimput_3.ipynb

最后主要用的是2和3，因为1预测的效果太差，最后通过观察的方式进行填补

## 数据分析
analysis.ipynb: info,describe,pandas_profiling

## 第一题

1_*.ipynb
通过岭回归方程计算未风化时的含量（逆归一化）

## 第二题

2_kmean_PCA.ipynb:两个思路：PCA+K-means++，K-means++（铅钡）

2_kmean.ipynb: K-means++（高钾）

2_upsample.ipynb: 过采样

2_bp.ipynb :bp神经网络预测，并使用sobol进行敏感检验


## 第三题

3.ipynb :模型集成，表单3预测，指标计算，敏感性分析


## 第四题

4.ipynb：使用find_frequent_patterns，没有用上。
使用SPSS，SPSSPRO等完成